DevBranch='master'
ReleaseBranch='release'
ConfigBranch='staging_config'
Version='1.0.0.0'